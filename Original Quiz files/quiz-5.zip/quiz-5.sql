PRAGMA foreign_keys = on;

SELECT "1----------";
.headers on
--put your code here
;
.headers off

SELECT "2----------";
.headers on
--put your code here
;

select * from Classes;
select * from Ships;
select * from Battles;
select * from Outcomes;
.headers off

SELECT "3----------";
.headers on
--put your code here
;

select * from Classes;
select * from Ships;
.headers off

SELECT "4----------";
.headers on
--put your code here
;

select * from Battles;
select * from Outcomes;
.headers off

SELECT "5----------";
.headers on
--put your code here
;

select * from Battles;
select * from Outcomes;
.headers off

SELECT "6----------";
.headers on
--put your code here
;

select * from Ships;
select * from Outcomes;
.headers off
