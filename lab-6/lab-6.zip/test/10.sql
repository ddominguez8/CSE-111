-- Find the region where customers 
-- spend the smallest amount of money 
-- (lextendedprice) buying items from 
-- suppliers in the same region.

