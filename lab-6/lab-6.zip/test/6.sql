-- Find the supplier-customer pair(s) with 
-- the least expensive (ototalprice) order(s) 
-- completed (F in oorderstatus).  Print the
-- supplier name, the customer name, and the total price.

-- SELECT 