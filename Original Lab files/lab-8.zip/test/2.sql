.eqp on

select min(s_acctbal)
from supplier;
